/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package av1;

import classes.Teste;
import classes.Conta;
import classes.ContaPoupanca;
import classes.ContaCorrente;

/**
 *
 * @author Arthur
 */
public class Av1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // ========== Conta de teste da classe TESTE ========= //
        Teste contaTeste0 =  new Teste("Nome titular", 123, "12445", 230.40, "10/20/2019");
        System.out.println(contaTeste0.toString());//Exibe atributos da contaTeste da classe de teste.
        
        // ========== Contas classe conta:Corrente e Poupanca =========== //
        ContaCorrente contaTeste1 =  new ContaCorrente(10, 210, "Nome titular", 123, "12445");
        ContaPoupanca contaTeste2 =  new ContaPoupanca(0.5, 5, "Nome titular 2", 456, "3456");
        
        contaTeste1.depositar(500);
        contaTeste1.sacar(150);
        contaTeste1.trasferir(contaTeste2, 100);
        
        System.out.println(contaTeste1.toString());
        
        contaTeste2.sacar(75);
        contaTeste2.depositar(800);
        contaTeste2.trasferir(contaTeste1, 110);
        
        System.out.println(contaTeste1.toString());
        System.out.println(contaTeste2.toString());
        
        System.out.println("Conta Teste1: " 
                                +   "\nImposto: "
                                +   contaTeste1.getValorImposto()
                                +   "\nTaxa manutenção: "
                                +   contaTeste1.getTaxaAdministracao());
        
        System.out.println("Conta Teste2: "
                                + "\nPorcentagem de rendimento: "
                                + contaTeste2.getPorcentagemRendimento()
                                + "\nRendimento do dia: "
                                + contaTeste2.getDiaRendimento());
        
    }
    
}
