/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.Date;

/**
 *
 * @author Arthur
 */
public class ContaCorrente extends Conta implements Tributavel{
    private double taxaAdministracao;
    private double limite;

    public ContaCorrente(double taxaAdministracao, double limite, String titular, int numero, String agencia) {
        this.taxaAdministracao = taxaAdministracao;
        this.limite = limite;
        this.setTitular(titular);
        this.setAgencia(agencia);
        this.setNumero(numero);
        Date data = new Date(System.currentTimeMillis());
        this.setDataAbertura(data.toString());
    }
    
    public double getTaxaAdministracao() {
        return taxaAdministracao;
    }

    public void setTaxaAdministracao(double taxaAdministracao) {
        this.taxaAdministracao = taxaAdministracao;
    }

    public double getLimite() {
        return limite;
    }

    public void setLimite(double limite) {
        this.limite = limite;
    }

    @Override
    public boolean sacar(double valor) {
        if(valor<this.getSaldo()){
            this.setSaldo(this.getSaldo()-valor);
            return true;
        }
        return false;
    }

    @Override
    public boolean depositar(double valor) {
        if(valor>0){
            this.setSaldo(this.getSaldo()+valor);
            return true;
        }
        return false;
    }

    @Override
    public boolean trasferir(Conta contaX, double valor) {
        if(valor>0&&valor<this.getSaldo()){
            this.sacar(valor);
            contaX.depositar(valor);
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Conta Corrente: "
                +   "\nNome do titular: "         +   this.getTitular()
                +   "\nNumero da agencia: "       +   this.getAgencia()
                +   "\nNumero da Conta: "         +   this.getNumero()
                +   "\nSaldo: "                   +   this.getSaldo()
                +   "\nData de abertura: "        +   this.getDataAbertura()
                +   "\nTaxa de adiministração: "  +   this.taxaAdministracao
                +   "\nLimite: "                  +   this.limite;
    }
    
    @Override
    public double getValorImposto() {
        return 0.01*getSaldo();
    }
    
}
