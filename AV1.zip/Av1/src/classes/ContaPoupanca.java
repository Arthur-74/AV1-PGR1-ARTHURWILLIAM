/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package classes;

import java.util.Date;

/**
 *
 * @author Arthur
 */
public class ContaPoupanca extends Conta {
    private double porcentagemRendimento;
    private int diaRendimento;

    public ContaPoupanca(double porcentagemRendimento, int diaRendimento, String titular, int numero, String agencia) {
        this.porcentagemRendimento = porcentagemRendimento;
        this.diaRendimento = diaRendimento;
        this.setTitular(titular);
        this.setNumero(numero);
        this.setAgencia(agencia);
        Date data = new Date(System.currentTimeMillis());
        this.setDataAbertura(data.toString());
    }

    public double getPorcentagemRendimento() {
        return porcentagemRendimento;
    }

    public void setPorcentagemRendimento(double porcentagemRendimento) {
        this.porcentagemRendimento = porcentagemRendimento;
    }

    public int getDiaRendimento() {
        return diaRendimento;
    }

    public void setDiaRendimento(int diaRendimento) {
        this.diaRendimento = diaRendimento;
    }

    @Override
    public boolean sacar(double valor) {
        if(valor<this.getSaldo()){
            this.setSaldo(this.getSaldo()-valor);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean depositar(double valor) {
        if(valor>0){
            this.setSaldo(this.getSaldo()+valor);
            return true;
        }
        return false;
    }
    
    @Override
    public boolean trasferir(Conta contaX, double valor) {
        if(valor>0&&valor<this.getSaldo()){
            this.sacar(valor);
            contaX.depositar(valor);
        }
        return false;
    }
    
    @Override
    public String toString() {
        return "Conta Poupanca: "
                +   "\nNome do titular: "             +   this.getTitular()
                +   "\nNumero da agencia: "           +   this.getAgencia()
                +   "\nNumero da conta: "             +   this.getNumero()
                +   "\nSaldo: "                       +   this.getSaldo()
                +   "\nData de Abertura: "            +   this.getDataAbertura()
                +   "\nRendimento do dia: "           +   this.diaRendimento
                +   "\nPorcentagem de Rendimento: "   +   this.porcentagemRendimento;
    }

    
    
}
